namespace nova com.yourcompany.demo.exception

exception DemoServiceException {
    1: string message
    2: i32 code
}