namespace nova com.yourcompany.demo.entity

enum ErrorLevel {
    DEBUG = 1,
    INFO = 2,
    WARN = 3,
    ERROR = 4
}