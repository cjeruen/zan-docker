<?php

return [
    'mysql.default_write' => [
        'TABLES',
        'COLUMNS',
    ],
];