<?php

return [
    "run" => true,
    "trace_class" => \Zan\Framework\Sdk\Trace\ZanTracer::class
];
