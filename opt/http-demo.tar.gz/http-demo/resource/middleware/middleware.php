<?php

return [
    'group'     => [

    ],
    'match'     => [
        ['/market\/.*/', 'acl'],
        ['/goods\/.*/', 'acl'],
        ['/shop\/.*/', 'acl'],
    ],
];