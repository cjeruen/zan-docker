<?php

return [
    'strategy' => 'polling'
];