<?php

return [
    'domain' => '.example.com',
    'path' => '/',
    'expire' => 2592000,
    'secure' => FALSE,
    'httponly' => FALSE,
    'salt' => '',
    'xss_filtering' => FALSE,
];
