<?php

return [
    'debug' => true,
];