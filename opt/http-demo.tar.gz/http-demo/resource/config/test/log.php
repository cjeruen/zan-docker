<?php

return [
    'debug'          => 'log://info/debug.log?useBuffer=false&format=json',
];