<?php

return [
    'path' => "/tmp/sql.log"
];