<?php
/**
 * Created by PhpStorm.
 * User: xiaoniu
 * Date: 16/4/19
 * Time: 上午9:58
 */
return [
    'connection' => 'redis.default_write',
    'test' => [
        'key' => 'test_abc'
    ],
];