<?php

return [
    'sql_path' => 'resource/sql/',
    'log_path' => 'resource/log/',
    'cache_path' => 'resource/cache/',
    'model_path' => 'resource/model/',
    'table_path' => 'resource/config/share/table/',
    'connection_path' => 'resource/config/dev/connection/',
];