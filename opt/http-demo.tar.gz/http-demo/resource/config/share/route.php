<?php

return [
    'default_route' => '/index',
    'default_controller' => 'index',
    'default_action' => 'index',
    'default_format' => 'html',
];
